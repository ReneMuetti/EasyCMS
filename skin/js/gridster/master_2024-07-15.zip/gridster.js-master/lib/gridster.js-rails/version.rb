module Gridster
  module Rails
    VERSION = "0.8.0"
  end
end
